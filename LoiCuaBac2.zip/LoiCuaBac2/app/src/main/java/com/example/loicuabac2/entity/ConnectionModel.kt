package com.example.loicuabac2.entity

class ConnectionModel(var type: Int, var isConnrcted: Boolean)