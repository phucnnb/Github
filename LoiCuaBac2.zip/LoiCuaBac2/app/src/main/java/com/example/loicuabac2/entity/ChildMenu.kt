package com.example.loicuabac2.entity

import com.google.gson.annotations.SerializedName

data class ChildMenu (
    @SerializedName("child")
    var child: String
)