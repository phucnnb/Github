package com.example.loicuabac2.service.download

interface DownloadInterface {
    fun getStringFormUrl(s : String)
}