package com.example.loicuabac2.view.readstory

interface ReadStoryView {
    fun setColorBackGround()
    fun setSizeText(size: Float)
}